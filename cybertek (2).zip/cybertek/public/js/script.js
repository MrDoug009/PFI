
const $ = seletor => document.querySelector(seletor);
const params = new URLSearchParams(location.search);
const ler = (chave, padrao) => JSON.parse(localStorage.getItem(chave)) ?? padrao;
const gravar = (chave, valor) => localStorage.setItem(chave, JSON.stringify(valor));
const barra = p => `<div class="barra"><div class="barra-preenchida" style="width:${p}%"></div></div>`;
const lista = itens => itens.map(i => `<li>${fmt(i)}</li>`).join('');
const NOMES = { quiz: 'Perguntas', simulacao: 'Simulação' };
function fmt(texto) {
  const d = document.createElement('div');
  d.textContent = texto;
  return d.innerHTML.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
}
function aviso(caixa, texto, tipo) {
  caixa.textContent = texto;
  caixa.className = 'alerta-msg ' + tipo;
  caixa.hidden = false;
}
async function hash(texto) {
  const bytes = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(texto));
  return [...new Uint8Array(bytes)].map(b => b.toString(16).padStart(2, '0')).join('');
}
const usuarios = () => ler('usuarios', []);
const logado = () => usuarios().find(u => u.email === ler('sessao', null));
const progresso = () => ler('progresso', {});
function dadosCat(email, cat) {
  return (progresso()[email] || {})[cat] || { feitas: [], notas: {} };
}
function salvarCat(email, cat, dados) {
  const p = progresso();
  p[email] = { ...p[email], [cat]: dados };
  gravar('progresso', p);
}
function apagarProgresso(email) {
  const p = progresso();
  delete p[email];
  gravar('progresso', p);
}
function atual(email, cat) {
  const feitas = dadosCat(email, cat).feitas;
  let n = 1;
  while (feitas.includes(n)) n++;
  return Math.min(n, CATEGORIAS[cat].etapas.length);
}
function status(email, cat, n) {
  if (dadosCat(email, cat).feitas.includes(n)) return 'concluida';
  return n === atual(email, cat) ? 'atual' : 'bloqueada';
}
function concluir(email, cat, n) {
  const d = dadosCat(email, cat);
  if (!d.feitas.includes(n)) d.feitas.push(n);
  salvarCat(email, cat, d);
}
function registrarNota(email, cat, tipo, res) {
  const d = dadosCat(email, cat);
  if (!d.notas[tipo] || res.pct > d.notas[tipo].pct) d.notas[tipo] = res;
  salvarCat(email, cat, d);
}
const percentual = (email, cat) => Math.round(dadosCat(email, cat).feitas.length / CATEGORIAS[cat].etapas.length * 100);
const urlEtapa = (cat, n) => CATEGORIAS[cat].etapas[n - 1].tipo === 'simulacao' ? '/simulacao?cat=' + cat : `/modulo?cat=${cat}&etapa=${n}`;
const email = e => `<div class="email"><div class="email-cabecalho"><div><strong>De:</strong> ${fmt(e.de)}</div><div><strong>Assunto:</strong> ${fmt(e.assunto)}</div></div>
  <div class="email-corpo">${e.corpo.map(p => `<p>${fmt(p)}</p>`).join('')}${e.link ? `<p><span class="link-falso">${fmt(e.link.texto)}</span>
  <button type="button" class="btn-link ver-link">Ver endereço do link</button><span class="destino-link" hidden>Endereço real: <code>${fmt(e.link.destino)}</code></span></p>` : ''}</div></div>`;

const caixa = (classe, titulo, texto) => `<div class="destaque ${classe}"><strong>${titulo}</strong><p>${fmt(texto)}</p></div>`;
const BLOCOS = {
  h: b => `<h2>${fmt(b.texto)}</h2>`,
  p: b => `<p>${fmt(b.texto)}</p>`,
  lista: b => `<ul>${lista(b.itens)}</ul>`,
  passos: b => `<ol>${lista(b.itens)}</ol>`,
  dica: b => caixa('dica', 'Dica', b.texto),
  alerta: b => caixa('alerta', 'Atenção', b.texto),
  exemplo: b => caixa('exemplo', fmt(b.titulo), b.texto),
  tabela: b => `<div class="tabela-rolagem"><table><tr>${b.cabecalho.map(c => `<th>${fmt(c)}</th>`).join('')}</tr>${b.linhas.map(l => `<tr>${l.map(c => `<td>${fmt(c)}</td>`).join('')}</tr>`).join('')}</table></div>`,
  email: b => email(b) + `<div class="sinais"><strong>O que observar:</strong><ul>${lista(b.sinais)}</ul></div>`,
  resumo: b => `<div class="resumo"><strong>Resumo da etapa</strong><ul>${lista(b.itens)}</ul></div>`,
  revisao: b => `<details class="revisao"><summary>Pergunta de revisão: ${fmt(b.pergunta)}</summary><p>${fmt(b.resposta)}</p></details>`
};
const blocos = lista => lista.map(b => BLOCOS[b.t](b)).join('');
const TIPOS = {
  escolha(area, it, responder) {
    const ops = it.opcoes.map((texto, i) => ({ texto, certa: i === it.correta }));
    if (ops.length > 2) ops.sort(() => Math.random() - 0.5); // embaralha (Verdadeiro/Falso e Seguro/Suspeito ficam na ordem)
    area.insertAdjacentHTML('beforeend', `<div class="opcoes ${ops.length === 2 ? 'duas' : ''}">${ops.map(o => `<button type="button" class="opcao">${fmt(o.texto)}</button>`).join('')}</div>`);
    const botoes = area.querySelectorAll('.opcao');
    botoes.forEach((botao, i) => botao.onclick = () => {
      botoes.forEach((b, j) => { b.disabled = true; if (ops[j].certa) b.classList.add('certa'); });
      if (!ops[i].certa) botao.classList.add('errada');
      responder(ops[i].certa, `<p>${fmt(it.explicacao)}</p>` + (it.sinais ? `<p><strong>Pontos importantes:</strong></p><ul>${lista(it.sinais)}</ul>` : ''));
    });
  },

  marcar(area, it, responder) {
    area.insertAdjacentHTML('beforeend', `<div class="email"><div class="email-corpo marcavel">${it.partes.map(p => `<button type="button" class="parte"><span class="parte-rotulo">${fmt(p.rotulo)}</span><span class="parte-texto">${fmt(p.texto)}</span></button>`).join('')}</div></div>
      <button type="button" class="btn btn-primario" id="verificar">Verificar</button>`);
    const botoes = area.querySelectorAll('.parte');
    botoes.forEach(b => b.onclick = () => b.classList.toggle('marcada'));
    $('#verificar').onclick = () => {
      let tudoCerto = true, detalhes = '';
      it.partes.forEach((p, i) => {
        const certo = botoes[i].classList.contains('marcada') === p.suspeito;
        tudoCerto = tudoCerto && certo;
        botoes[i].disabled = true;
        botoes[i].classList.add(certo ? 'parte-certa' : 'parte-errada');
        detalhes += `<li><strong>${fmt(p.rotulo)}:</strong> ${certo ? '✓' : '✗'} ${p.suspeito ? 'Era suspeito.' : 'Era normal.'} ${fmt(p.motivo)}</li>`;
      });
      $('#verificar').disabled = true;
      responder(tudoCerto, `<p>${fmt(it.explicacao)}</p><ul class="detalhes">${detalhes}</ul>`);
    };
  },

  senha(area, it, responder) {
    const regras = [
      ['Pelo menos 12 caracteres', s => s.length >= 12],
      ['Uma letra maiúscula', s => /[A-Z]/.test(s)],
      ['Uma letra minúscula', s => /[a-z]/.test(s)],
      ['Um número', s => /\d/.test(s)],
      ['Um símbolo (! ? - _ @ # ...)', s => /[^A-Za-z0-9]/.test(s)],
      ['Sem sequências comuns (123, abc, qwerty, senha)', s => !/123|abc|qwerty|senha/i.test(s)]
    ];
    area.insertAdjacentHTML('beforeend', `<input type="password" id="campo" autocomplete="off" maxlength="64"><ul class="criterios" id="criterios"></ul>
      <button type="button" class="btn btn-primario" id="verificar">Verificar senha</button>`);
    const mostrar = () => $('#criterios').innerHTML = regras.map(([texto, ok]) => `<li class="${ok($('#campo').value) ? 'cumprido' : 'pendente'}">${ok($('#campo').value) ? '✓' : '○'} ${texto}</li>`).join('');
    mostrar();
    $('#campo').oninput = mostrar;
    $('#verificar').onclick = () => {
      const cumpridos = regras.filter(([, ok]) => ok($('#campo').value)).length;
      $('#campo').disabled = $('#verificar').disabled = true;
      responder(cumpridos === regras.length, `<p>Sua senha de teste cumpriu ${cumpridos} de ${regras.length} critérios. Uma frase longa, com palavras sem relação entre si, é o caminho mais fácil.</p>`);
    };
  }
};
function exercicios(alvo, itens, titulo, aoFinal) {
  let i = 0, acertos = 0;

  function mostrar() {
    const it = itens[i];
    alvo.innerHTML = `<p class="contador">${titulo} ${i + 1} de ${itens.length}</p>${barra(i / itens.length * 100)}<div class="cartao exercicio" id="exercicio"></div><div id="feedback"></div>`;
    $('#exercicio').innerHTML = (it.contexto ? `<p class="contexto">${fmt(it.contexto)}</p>` : '') + (it.email ? email(it.email) : '') + `<h3>${fmt(it.pergunta)}</h3>`;
    TIPOS[it.tipo]($('#exercicio'), it, responder);
  }

  function responder(acertou, feedback) {
    if (acertou) acertos++;
    const ultimo = i === itens.length - 1;
    $('#feedback').innerHTML = `<div class="feedback ${acertou ? 'ok' : 'erro'}"><strong>${acertou ? '✓ Você acertou!' : '✗ Não foi dessa vez.'}</strong>${feedback}</div>
      <div class="acoes"><button type="button" class="btn btn-primario" id="proximo">${ultimo ? 'Ver resultado' : 'Próximo'}</button></div>`;
    $('#proximo').onclick = () => {
      if (!ultimo) { i++; mostrar(); }
      else aoFinal({ acertos, total: itens.length, pct: Math.round(acertos / itens.length * 100) });
    };
  }

  mostrar();
}
function treinar(alvo, u, cat, n, itens, tipo, titulo, minimo) {
  exercicios(alvo, itens, titulo, res => {
    const passou = res.pct >= minimo;
    registrarNota(u.email, cat, tipo, res);
    if (passou) concluir(u.email, cat, n);
    alvo.innerHTML = `<div class="cartao resultado ${passou ? 'aprovado' : 'reprovado'}"><p class="contador">Resultado</p>
      <p class="resultado-nota">${res.acertos}/${res.total} — ${res.pct}%</p>${barra(res.pct)}
      <p>${passou ? 'Muito bem! Você pode avançar para a próxima etapa.' : `Ainda não foi suficiente (mínimo de ${minimo}%). Revise o conteúdo e tente de novo.`}</p></div>
      <div class="acoes">${passou ? `<a class="btn btn-primario" href="${urlEtapa(cat, n + 1)}">Avançar para a próxima etapa</a>` : `<a class="btn btn-contorno" href="/categoria?cat=${cat}">Rever o conteúdo</a>`}
      <button type="button" class="btn btn-contorno" id="refazer">Refazer</button></div>`;
    $('#refazer').onclick = () => treinar(alvo, u, cat, n, itens, tipo, titulo, minimo);
    window.scrollTo(0, 0);
  });
}
function podeAbrir(u, cat, n) {
  const ok = CATEGORIAS[cat] && n >= 1 && n <= CATEGORIAS[cat].etapas.length && n <= atual(u.email, cat);
  if (!ok) location.replace(CATEGORIAS[cat] ? '/categoria?cat=' + cat : '/dashboard');
  return ok;
}

function cabecalho(prefixo, cat, n) {
  const c = CATEGORIAS[cat];
  $(`#${prefixo}-trilha`).innerHTML = `<a href="/categoria?cat=${cat}">← ${c.nome}</a>`;
  $(`#${prefixo}-titulo`).textContent = `Etapa ${n}: ${c.etapas[n - 1].titulo}`;
  $(`#${prefixo}-progresso`).innerHTML = barra((n - 1) / c.etapas.length * 100) + `<p class="meta">Etapa ${n} de ${c.etapas.length}</p>`;
}

const PAGINAS = {
  index(u) {
    if (u) $('#acoes-hero').innerHTML = '<a href="/dashboard" class="btn btn-primario">Ir para o treinamento</a><a href="#treinamento" class="btn btn-contorno">Conhecer o treinamento</a>';
    $('#cartoes-categorias').innerHTML = Object.values(CATEGORIAS).map(c =>
      `<article class="cartao categoria-cartao"><div class="icone">${c.icone}</div><h3>${c.nome}</h3><p>${c.descricao}</p><p class="meta">${c.etapas.length} etapas, ${c.duracao}</p></article>`).join('');
  },

  login() {
    const msg = $('#msg');
    if (params.get('aviso')) aviso(msg, 'Entre na sua conta para acessar o treinamento.', 'info');
    if (params.get('conta')) aviso(msg, 'Conta criada! Agora é só entrar.', 'ok');
    $('#form-login').onsubmit = async e => {
      e.preventDefault();
      const mail = $('#email').value.trim().toLowerCase(), senha = $('#senha').value;
      if (!mail || !senha) return aviso(msg, 'Preencha o e-mail e a senha.', 'erro');
      const usuario = usuarios().find(x => x.email === mail);
      if (!usuario || usuario.senha !== await hash(mail + senha)) return aviso(msg, 'E-mail ou senha incorretos.', 'erro');
      gravar('sessao', mail);
      location.href = '/dashboard';
    };
  },

  cadastro() {
    $('#form-cadastro').onsubmit = async e => {
      e.preventDefault();
      const nome = $('#nome').value.trim(), mail = $('#email').value.trim().toLowerCase(), senha = $('#senha').value;
      const regras = [   // [condição de erro, mensagem]
        [!nome, 'Informe seu nome.'],
        [!/^\S+@\S+\.\S+$/.test(mail), 'Informe um e-mail válido.'],
        [senha.length < 8, 'A senha precisa ter pelo menos 8 caracteres.'],
        [senha !== $('#confirmar').value, 'A confirmação de senha não confere.'],
        [usuarios().some(x => x.email === mail), 'Já existe uma conta com esse e-mail.']
      ];
      const erro = regras.find(r => r[0]);
      if (erro) return aviso($('#msg'), erro[1], 'erro');
      gravar('usuarios', [...usuarios(), { nome, email: mail, senha: await hash(mail + senha) }]);
      location.href = '/login?conta=criada';
    };
  },

  dashboard(u) {
    $('#saudacao').textContent = 'Olá, ' + u.nome.split(' ')[0] + '!';
    const cats = Object.values(CATEGORIAS);
    const total = cats.reduce((soma, c) => soma + c.etapas.length, 0);
    const feitas = cats.reduce((soma, c) => soma + dadosCat(u.email, c.id).feitas.length, 0);
    const geral = Math.round(feitas / total * 100);
    $('#resumo-geral').innerHTML = `<div class="estatistica"><span class="numero">${geral}%</span><span>do treinamento concluído</span></div><div class="estatistica"><span class="numero">${feitas}/${total}</span><span>etapas concluídas</span></div>`;
    $('#barra-geral').innerHTML = barra(geral);
    const ultima = ler('categoria', null);
    if (ultima) $('#atalho').innerHTML = `<a class="btn btn-primario" href="${urlEtapa(ultima, atual(u.email, ultima))}">Continuar: ${CATEGORIAS[ultima].nome}</a>`;
    $('#lista-categorias').innerHTML = cats.map(c => {
      const d = dadosCat(u.email, c.id);
      const notas = Object.entries(d.notas).map(([tipo, r]) => `${NOMES[tipo]}: ${r.pct}%`).join(', ');
      return `<article class="cartao categoria-cartao"><div class="icone">${c.icone}</div><h3>${c.nome}</h3><p>${c.descricao}</p>${barra(percentual(u.email, c.id))}
        <p class="meta">${d.feitas.length} de ${c.etapas.length} etapas${notas ? ' · melhores notas: ' + notas : ''}</p>
        <a class="btn btn-primario" href="/categoria?cat=${c.id}">${d.feitas.length ? 'Continuar' : 'Começar'}</a></article>`;
    }).join('');
  },

  categoria(u) {
    const cat = params.get('cat'), c = CATEGORIAS[cat];
    if (!c) return location.replace('/dashboard');
    gravar('categoria', cat);
    $('#cat-titulo').textContent = c.icone + ' ' + c.nome;
    $('#cat-descricao').textContent = c.descricao;
    $('#cat-barra').innerHTML = barra(percentual(u.email, cat)) + `<p class="meta">${percentual(u.email, cat)}% concluído</p>`;
    $('#lista-etapas').innerHTML = c.etapas.map((e, i) => {
      const s = status(u.email, cat, i + 1);
      const conteudo = `<span class="etapa-icone">${{ concluida: '✓', atual: '→', bloqueada: '🔒' }[s]}</span><span class="etapa-texto"><strong>Etapa ${i + 1}: ${e.titulo}</strong><span class="meta">${{ concluida: 'Concluída', atual: 'Em andamento', bloqueada: 'Bloqueada' }[s]}</span></span>`;
      return `<li class="etapa ${s}">${s === 'bloqueada' ? conteudo : `<a href="${urlEtapa(cat, i + 1)}">${conteudo}</a>`}</li>`;
    }).join('');
  },

  modulo(u) {   // etapas de leitura, perguntas e conclusão
    const cat = params.get('cat'), n = +params.get('etapa');
    if (!podeAbrir(u, cat, n)) return;
    const e = CATEGORIAS[cat].etapas[n - 1], alvo = $('#mod-conteudo');
    if (e.tipo === 'simulacao') return location.replace('/simulacao?cat=' + cat);
    cabecalho('mod', cat, n);

    if (e.tipo === 'quiz') {
      alvo.innerHTML = `<div class="cartao"><p>Responda às ${e.perguntas.length} perguntas. Você precisa de pelo menos <strong>${QUIZ_MIN}%</strong> para avançar.</p><div class="acoes"><button type="button" class="btn btn-primario" id="iniciar">Começar as perguntas</button></div></div>`;
      $('#iniciar').onclick = () => treinar(alvo, u, cat, n, e.perguntas, 'quiz', 'Pergunta', QUIZ_MIN);
      return;
    }
    const notas = Object.entries(dadosCat(u.email, cat).notas).map(([tipo, r]) => `<li>${NOMES[tipo]}: <strong>${r.acertos}/${r.total} (${r.pct}%)</strong></li>`).join('');
    const leitura = e.tipo === 'leitura';
    alvo.innerHTML = `<div class="cartao leitura">${blocos(e.blocos)}${!leitura && notas ? `<div class="resumo"><strong>Seu desempenho</strong><ul>${notas}</ul></div>` : ''}</div>
      <div class="acoes">${n > 1 ? `<a class="btn btn-contorno" href="${urlEtapa(cat, n - 1)}">Etapa anterior</a>` : ''}
      <button type="button" class="btn btn-primario" id="concluir">${leitura ? 'Concluir etapa e continuar' : 'Finalizar categoria'}</button></div>`;
    $('#concluir').onclick = () => {
      concluir(u.email, cat, n);
      location.href = leitura ? urlEtapa(cat, n + 1) : '/dashboard';
    };
  },

  simulacao(u) {
    const cat = params.get('cat'), c = CATEGORIAS[cat];
    const n = c ? c.etapas.findIndex(e => e.tipo === 'simulacao') + 1 : 0;
    if (!podeAbrir(u, cat, n)) return;
    cabecalho('sim', cat, n);
    const e = c.etapas[n - 1], alvo = $('#sim-conteudo');
    alvo.innerHTML = `<div class="cartao"><p>${fmt(e.introducao)}</p><p>Para concluir é preciso pelo menos <strong>${SIM_MIN}%</strong> de acertos.</p>
      <div class="acoes"><a class="btn btn-contorno" href="${urlEtapa(cat, n - 1)}">Etapa anterior</a><button type="button" class="btn btn-primario" id="iniciar">Iniciar simulação</button></div></div>`;
    $('#iniciar').onclick = () => treinar(alvo, u, cat, n, e.itens, 'simulacao', 'Cenário', SIM_MIN);
  },

  perfil(u) {
    const msg = $('#msg');
    $('#nome').value = u.nome;
    $('#email').value = u.email;
    if (params.get('salvo')) aviso(msg, 'Dados atualizados com sucesso.', 'ok');

    $('#form-perfil').onsubmit = async e => {
      e.preventDefault();
      const nome = $('#nome').value.trim(), mail = $('#email').value.trim().toLowerCase();
      const atualSenha = $('#senha-atual').value, nova = $('#nova-senha').value;
      const regras = [
        [!nome, 'Informe seu nome.'],
        [!/^\S+@\S+\.\S+$/.test(mail), 'Informe um e-mail válido.'],
        [await hash(u.email + atualSenha) !== u.senha, 'A senha atual está incorreta.'],
        [nova && nova.length < 8, 'A nova senha precisa ter pelo menos 8 caracteres.'],
        [nova && nova !== $('#confirmar').value, 'A confirmação não confere com a nova senha.'],
        [mail !== u.email && usuarios().some(x => x.email === mail), 'Já existe outra conta com esse e-mail.']
      ];
      const erro = regras.find(r => r[0]);
      if (erro) return aviso(msg, erro[1], 'erro');
      const novoHash = await hash(mail + (nova || atualSenha));
      gravar('usuarios', usuarios().map(x => x.email === u.email ? { nome, email: mail, senha: novoHash } : x));
      const p = progresso();
      if (mail !== u.email && p[u.email]) { p[mail] = p[u.email]; delete p[u.email]; gravar('progresso', p); }
      gravar('sessao', mail);
      location.href = '/perfil?salvo=1';
    };

    $('#btn-reiniciar').onclick = () => {
      if (confirm('Apagar todo o seu progresso e suas notas? A conta será mantida.')) { apagarProgresso(u.email); aviso(msg, 'Progresso reiniciado.', 'ok'); }
    };
    $('#btn-excluir').onclick = () => {
      if (!confirm('Excluir a conta permanentemente? Isso não pode ser desfeito.')) return;
      gravar('usuarios', usuarios().filter(x => x.email !== u.email));
      apagarProgresso(u.email);
      localStorage.removeItem('sessao');
      location.href = '/';
    };
  }
};
function topo(u) {
  $('#navbar').className = 'topo';
  $('#navbar').innerHTML = `<div class="topo-conteudo"><a href="/" class="logo"><span class="logo-marca">CT</span>CyberTek</a><nav class="menu">${u
    ? '<a href="/dashboard">Treinamento</a><a href="/perfil">Perfil</a><button type="button" id="sair" class="btn btn-contorno btn-pequeno">Sair</button>'
    : '<a href="/login">Entrar</a><a href="/cadastro" class="btn btn-primario btn-pequeno">Criar conta</a>'}</nav></div>`;
  $('#rodape').className = 'rodape';
  $('#rodape').innerHTML = '<p>CyberTek é um projeto educacional. Todos os e-mails e cenários são fictícios. Esta versão (MVP) usa login e progresso simulados no navegador, sem banco de dados.</p>';
  if (u) $('#sair').onclick = () => { localStorage.removeItem('sessao'); location.href = '/'; };
}
document.addEventListener('click', e => {
  if (e.target.classList.contains('ver-link')) e.target.nextElementSibling.hidden = !e.target.nextElementSibling.hidden;
});

const pagina = document.body.dataset.page;
const usuario = logado();
topo(usuario);
if (['dashboard', 'categoria', 'modulo', 'simulacao', 'perfil'].includes(pagina) && !usuario) location.replace('/login?aviso=1');
else if (['login', 'cadastro'].includes(pagina) && usuario) location.replace('/dashboard');
else if (PAGINAS[pagina]) PAGINAS[pagina](usuario);
