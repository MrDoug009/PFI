const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

app.disable('x-powered-by');
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  next();
});
app.use(express.static(path.join(__dirname, 'public')));
const paginas = {
  '/': 'index',
  '/login': 'login',
  '/cadastro': 'cadastro',
  '/dashboard': 'dashboard',
  '/categoria': 'categoria',
  '/modulo': 'modulo',
  '/simulacao': 'simulacao',
  '/perfil': 'perfil'
};

Object.entries(paginas).forEach(([rota, arquivo]) => {
  app.get(rota, (req, res) => {
    res.sendFile(path.join(__dirname, 'views', arquivo + '.html'));
  });
});
app.use((req, res) => {
  res.status(404).sendFile(path.join(__dirname, 'views', '404.html'));
});

app.listen(PORT, () => {
  console.log(`CyberTek rodando em http://localhost:${PORT}`);
});
